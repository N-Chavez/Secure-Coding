// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());
    // if not empty, what must the size be?
    EXPECT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());
    // if not empty, what must the size be?
    EXPECT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxIsGreaterThanSize)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // is the max size greater than the collection size?
    EXPECT_GE(collection->max_size(), collection->size());

    // add 1 entry
    add_entries(1);

    EXPECT_GE(collection->max_size(), collection->size());

    // add 4 entries for a total of 5
    add_entries(4);

    EXPECT_GE(collection->max_size(), collection->size());

    // add 5 entries for a total of 10
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapIsGreaterThanSize)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // is the capacity greater than the collection size?
    ASSERT_GE(collection->capacity(), collection->size());

    // add 1 entry
    add_entries(1);

    ASSERT_GE(collection->capacity(), collection->size());

    // add 4 entries for a total of 5
    add_entries(4);

    ASSERT_GE(collection->capacity(), collection->size());

    // add 5 entries for a total of 10
    add_entries(5);
    ASSERT_GE(collection->capacity() , collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, DoesResizingIncrease)
{
    unsigned int a;
    unsigned int b;

    // initial collection size
    a = collection->size();

    // resize the collection by +10
    collection->resize(10);

    // collection size after resizing
    b = collection->size();

    // b should be greater than a
    EXPECT_GT(b, a);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, DoesResizingDecrease)
{
    unsigned int a;
    unsigned int b;


    // resize the collection by +10
    collection->resize(10);

    // initial collection size
    a = collection->size();

    // resize the collection by -5
    collection->resize(5);

    // collection size after resizing
    b = collection->size();

    // b should be greater than a
    EXPECT_LT(b, a);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, DoesResizingSetToZero)
{
    // set the size of the collection to 5
    collection->resize(5);

    // verify that the size was changed
    EXPECT_EQ(collection->size(), 5);

    // use resize to set to 0
    collection->resize(0);

    // is the size 0?
    EXPECT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // add some entries to the collection
    add_entries(10);

    // clear the collection
    collection->clear();

    // is collection now empty?
    EXPECT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseErasesCollection)
{
    // add some entries
    add_entries(10);

    // erase entries from beginning to end
    collection->erase(collection->begin(), collection->end());

    // is collection now empty?
    EXPECT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapNotSize)
{
    unsigned int initCap;
    unsigned int initSize;
    unsigned int finalCap;
    unsigned int finalSize;

    // get the initial capacity and size of the collection
    initCap = collection->capacity();
    initSize = collection->size();

    collection->reserve(50);

    // get the capactiy and size after the reserve
    finalCap = collection->capacity();
    finalSize = collection->size();

    // is the capacity increased after the reserve?
    EXPECT_GT(finalCap, initCap);

    // did the size remain the same?
    EXPECT_EQ(finalSize, initSize);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRangeExceptionIsThrown)
{
    // out of range index
    unsigned int OORIndex = 24;

    // does out of range access throw exception?
    ASSERT_THROW(collection->at(OORIndex), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// test confirms that popping back an element removes the last element of the collection
TEST_F(CollectionTest, PushBackAppends)
{
    // add elements by using push_back
    collection->push_back(8);
    collection->push_back(4);

    // confirm the last element added is at the back
    EXPECT_EQ(collection->back(), 4);

    // pop back (remove) the last element of the collection
    collection->pop_back();

    // was the last element dropped?
    EXPECT_EQ(collection->back(), 8);

}

// test verifies that trying to reserve space that exceeds the maximum length for the collection
// throws the std::length_error exception
TEST_F(CollectionTest, LengthErrorExceptionIsThrown)
{
    // number exceeding allowable vector index max
    unsigned int tooBigIndex = ((collection->max_size()) + 5); 

    // does reserving to an index too high throw the exception?
    ASSERT_THROW(collection->reserve(tooBigIndex), std::length_error);
}